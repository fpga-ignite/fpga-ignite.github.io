Exercise 2: Count wires and cells
=================================

Implement a simple pass with options. Use selections.

Step 1:
-------

Open the file `count.cc`. In the space marked with "// *** Insert your code here ***", implement the functionality to count the number of wires and cells in the selection, as described in the command's help message.

Test the functionality by running `make test1`. This will compile the plugin and run the yosys commands from `test1.ys`. 

Step 2:
-------

Modify the script test1.ys to count the number of public wires only by adding a selection argument to `count -wires`.

Compare the counts given by your pass to the public wires and cells that you can see in the circuit diagram `test1.png` generated using the `show` command.

Step 3:
-------

Open the file test2.ys and complete the script to count the wires and cells of design test2.

Since this design is a bit larger, compare the number given by `count` to the numbers obtained by calling `stat`.
