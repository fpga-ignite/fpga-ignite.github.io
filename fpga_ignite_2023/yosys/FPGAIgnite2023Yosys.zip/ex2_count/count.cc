#include "kernel/yosys.h"

USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN

struct CountWiresAndCellsPass : public Pass {
	CountWiresAndCellsPass() : Pass("count", "count number of wires/cells") { }

	void help() override
	{
		//   |---v---|---v---|---v---|---v---|---v---|---v---|---v---|---v---|---v---|---v---|
		log("\n");
		log("    count [options] [selection]\n");
		log("\n");
		log("    -wires\n");
		log("        count wires\n");
		log("\n");
		log("    -cells\n");
		log("        count cells\n");
		log("\n");
		log("This pass counts the number of wires and/or cells in the design (selection).\n");
	}

	void execute(std::vector<std::string> args, Design *design) override {

		bool count_wires = false;
		bool count_cells = false;

		size_t argidx;
		for (argidx = 1; argidx < args.size(); argidx++) {
			if (args[argidx] == "-wires") {
				count_wires = true;
				continue;
			}
			if (args[argidx] == "-cells") {
				count_cells = true;
				continue;
			}
			break;
		}
		extra_args(args, argidx, design);

		if (!count_wires && !count_cells)
			log_error("Must specify at least one of \"-cells\" or \"-wires\".\n");


		log("Executing COUNT pass.\n");
		int num = 0;

		// *** Insert your code here ***

		log("Counted %d %s%s%s.\n", num, count_wires ? "wires" : "", (count_wires && count_cells) ? " and " : "", count_cells ? "cells" : "");
	}
} CountWiresAndCellsPass;

PRIVATE_NAMESPACE_END
