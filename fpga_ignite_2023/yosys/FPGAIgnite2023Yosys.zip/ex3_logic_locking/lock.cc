#include "kernel/yosys.h"
#include "kernel/celltypes.h"

USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN

struct LockLogicPass : public Pass {
	LockLogicPass() : Pass("lock", "add logic locking to a circuit") { }

	void help() override
	{
		//   |---v---|---v---|---v---|---v---|---v---|---v---|---v---|---v---|---v---|---v---|
		log("\n");
		log("    lock [options]\n");
		log("\n");
		log("    -key <value>\n");
		log("        use this key to unlock the functionality. Mandatory.\n");
		log("\n");
		log("    -module <name>\n");
		log("        Module to add the port and locking functionality to. By default the top module is chosen\n");
		log("\n");
		log("    -seed <value>\n");
		log("        seed for the pseudo-random generator picking the ports.\n");
		log("\n");
		log("This pass adds (naive) logic locking to the top level module in the design.\n");
	}


	uint32_t xorshift32_state = 123456789;

	uint32_t random_value(uint32_t limit) {
		xorshift32_state ^= xorshift32_state << 13;
		xorshift32_state ^= xorshift32_state >> 17;
		xorshift32_state ^= xorshift32_state << 5;
		return xorshift32_state % limit;
	}

	void insert_xor_lock(Module* mod, Cell* cell, IdString port, SigBit key_input_bit, bool key_value) {
		log_debug("Locking port %s of cell %s with key value %s\n", log_id(port), log_id(cell->name), key_value ? "1" : "0");
		log_assert(cell->hasPort(port));
		log_assert(cell->getPort(port).size() == 1);

		// *** Insert your code here ***
	}


	void execute(std::vector<std::string> args, Design *design) override {

		std::string key;
		IdString key_input_name = ID(logic_key);
		Module* top_module = design->top_module();

		size_t argidx;
		for (argidx = 1; argidx < args.size(); argidx++) {
			if (args[argidx] == "-key" && argidx + 1 < args.size()) {
				key = args[++argidx];
				continue;
			}
			if (args[argidx] == "-module" && argidx + 1 < args.size()) {
				IdString mod_name = RTLIL::escape_id(args[++argidx]);
				if (!design->module(mod_name))
					log_cmd_error("Module %s not found.\n", log_id(mod_name));
				top_module = design->module(mod_name);
				continue;
			}
			if (args[argidx] == "-seed" && argidx + 1 < args.size()) {
				xorshift32_state = atoi(args[++argidx].c_str());
				continue;
			}
			break;
		}
		extra_args(args, argidx, design);

		if (key.empty())
			log_cmd_error("Missing -key option.\n");
		
		if (key.find_first_not_of("01") != std::string::npos)
			log_cmd_error("Key contains character other than '0' or '1': %s\n", key.c_str());
		
		if (!top_module)
			log_cmd_error("No top module found.\n");

		if (top_module->wire(key_input_name))
			log_error("Top module already has a wire named \"%s\". Did you already run the logic locking pass?", log_id(key_input_name));

		log("Executing LOCK pass.\n");

		log_debug("Key value: %s\n", key.c_str());

		// *** Insert your code here ***

	}
} LockLogicPass;

PRIVATE_NAMESPACE_END
