Exercise 3: Logic locking
=========================

Logic locking is a technique where a design is rendered nonfunctional unless a specific key is input to the design.
We will implement a simple (naive) way to add logic locking to a design loaded into yosys.
Given a key of N bits and a design, this pass should:
    - add an N-bit input named "logic_key" to the top module
    - select N cell port bits in the design
    - insert a $_XOR_ gate in front of each selected cell port bit
    - depending on the corresponding key bit, insert a $_NOT_ gate between the key input bit and the $_XOR_ gate

We will use formal verification with a miter circuit in SBY to confirm that if the correct key is given, the design function remains the same.

There are many ways to achieve this functionality, the below steps are merely one suggestion. Feel free to experiment with alternative implementations!

Step 1:
-------

Examine the prepared tests, in the directories test1 and test2. Test1 is a small combinatorial circuit that is good for debugging. Test2 is a larger design that should be used to confirm the correct functioning once test1 passes.

Test1 has two modes:
 - `make test` runs the script from test1.ys. This script creates visual depictions of the circuit using the `show` command and is mainly for active debugging. We will complete this script in this step.
 - `make verify` runs the script from make_miter.ys to build a miter circuit, and then runs a bounded model check in SBY on an assertion that the outputs are always identical. This script will only work once the lock pass is completed enough to add an input named `logic_key` to the module.

Test2 only has the `verify` mode.

Since we want to xor with single-bit values, a gate-level netlist is most suitable to work on. To keep the input design recognizable, test1 uses `prep` and `techmap` to create a gate-level netlist close to the input design. Test2 uses `synth` to create a fully optimized gate-level netlist such as you would use in an ASIC design.

In the file test1.ys, add a call to the `lock` pass in the indicated place. Start easy with a 1-bit key, and increase the key length later when the lock pass is fully implemented.

Run `make test` to compile and run. As the lock pass is not implemented yet, the before and after designs in the schematic diagrams `test1.png` and `test1.locked.png` should be identical.

Add `debug` in front of the call to `lock` in `test1.ys`. Run the test again and check that the key value is printed to the terminal when executing the lock pass.


Step 2:
-------

In `lock.cc`, add code to create a new input port the size of the key argument. As name, use the variable `key_input_name` that has been defined for you. Don't forget to run fixup_ports() after making modifications to the ports of a module!

Run `make test` and confirm that there is now a new input port named `logic_key` appearing in test1.locked.png.

Now that the input port is added, you should be able to run `make verify`. Since no modification was made yet to the circuit functionality, it should return PASS.


Step 3:
-------

In the designated place in execute(), gather a list of candidate cell ports that could be used, from which you can later choose as many as you need for a given key width. For example, you could use the following data structure for a list of (cell, portname) combinations:
    std::vector<std::pair<Cell*, IdString>> lockable_cell_ports;

To be a candidate, the following requirements should be met:
    - the cell is part of the yosys internal cell library
    - the port is exactly 1 bit wide
    - if the cell is a kind of flip-flop, only the D and Q ports can be selected (as clock or reset signals should not be driven by logic)

You can also consider whether you want to select only input or output ports, or both.

Use `log_error()` to abort execution if there are no candidates identified.

For now, use `log_debug()` to print the number of identified ports. More checks will follow in the next steps.


Step 4:
-------

The function `insert_xor_lock()` has been declared for you early in the file. For now it does not perform any function, but it does print a debug message with information about the operation to be performed. Implement a loop that selects a candidate cell port for each bit in the input key, and calls `insert_xor_lock()` with the appropriate arguments. If you would like to randomize the cell port selection, you can use the provided pseudo-random number generation function `random_value()`.

Run `make test` and confirm that the printed cell and port information is as expected. Especially check the order of the key bits: the character at index 0 in the string `key` should be the most significant bit, and the last character the LSB.

Also consider what you want to happen if the key has more bits than there are identified candidate ports in your list. (Test this by increasing the key length in test1.ys.)

Step 5:
-------

Now implement the contents of the function `insert_xor_lock()` to add a $_XOR_ gate in front of the selected port, and a $_NOT_ gate for the key input bit if the key value at this bit is 1.

Make use of `make test` and `make verify` to check your implementation. If these pass, also run `make verify` in test2.

Once they are passing, confirm that the bounded model checks are working correctly by deliberately changing one bit in the `connect -set logic_key` line in the script to input a wrong key value.


Extra credit
------------

If you are done early, there are a variety of things you can explore. For example:
    - From the XOR+NOT structure it is very obvious just by looking what the correct key value is. Re-run `synth` after locking the design to partially merge the locking logic into the surrounding design and make it less easy to reverse engineer the key value. If you map to a LUT-based representation with `synth -lut <N>` the key will be very hard to recover from looking at the circuit diagram (but $lut cells are not supported in formal verification, so you would have to unmap them again to run verify).
    - The design might already have an input port named `logic_key`. Add an option to the pass that allows giving a custom name to the created input.
    - If a design is partially selected, many yosys passes restrict their operations to only the selection. Can you adjust your pass to only consider cells in the selection? Try to target e.g. only $_OR_ cells or only $_AND_ cells.
    - Bounded model checks are not complete proofs if the design contains state (registers or memory cells). Looking at the design test2.v, can you guess how many cycles it will need to propagate any difference in internal values to the output? If you lower the `depth` option in test2.sby to be smaller, can you make the check pass for an incorrect key value?
    - K-induction is a complete proof method. Can you make test2 pass in prove mode? (Don't hesitate to ask for more information if you want to try this. `abc pdr` is the easiest engine to make pass in prove mode, for other engines you will likely need to add some assertions about the state in both circuits.)
