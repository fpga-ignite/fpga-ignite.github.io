#include "kernel/yosys.h"

USING_YOSYS_NAMESPACE
PRIVATE_NAMESPACE_BEGIN

struct HelloWorldPass : public Pass {

	HelloWorldPass() : Pass("hello", "print \"Hello World!\" to the log") { }

	void help() override
	{
		//   |---v---|---v---|---v---|---v---|---v---|---v---|---v---|---v---|---v---|---v---|
		log("\n");
		log("    hello\n");
		log("\n");
		log("This prints \"Hello World!\" to the log.\n");
	}

	void execute(std::vector<std::string>, Design*) override {
		log("Hello World!\n");
	}

} HelloWorldPass;

PRIVATE_NAMESPACE_END
