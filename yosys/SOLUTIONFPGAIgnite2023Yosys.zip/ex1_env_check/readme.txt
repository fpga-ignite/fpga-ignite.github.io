Exercise 1: Hello World
=======================

Test that you can compile and run a plugin correctly. Take basic steps navigating the yosys command line interface.

Step 1:
-------

The code in hello.cc implements a custom yosys pass. The Makefile contains commands to compile this pass into a 

In a terminal, navigate to this directory (ex1_env_check) and run `make`.
This should build a plugin named hello.so, load it into yosys, and run the `hello` command.

Confirm that `make` succeeds and you get output that includes the following lines:

    -- Running command `hello' --
    Hello World!


Step 2:
-------

Enter yosys interactive mode by typing `yosys` in the terminal.

In the yosys prompt, load the plugin:
    yosys> plugin -i hello.so

Display the list of commands available in yosys:
    yosys> help
Confirm that `hello` is included in this list after loading the plugin.

Display the help message included with the new `hello` command:
    yosys> help hello

Run the `hello` command:
    yosys> hello

Exit the yosys interactive shell by typing ^D or with the command `exit`.
    yosys> exit